

<?php $__env->startSection('mycss'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.css" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.24.0/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/locale/fr.js"></script>
<script src="https://npmcdn.com/flatpickr@4.6.13/dist/l10n/fr.js"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
<script src="https://cdn.jsdelivr.net/npm/flatpickr" defer></script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('mytitle'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0 font-size-18">Detail Sur Les changements</h4>
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Detail Sur Les changements</a></li>
                    <li class="breadcrumb-item active">Acceuil</li>
                </ol>
            </div>
        </div>
    </div>
    <div>
        
    </div>
</div>
<div class="row">
    <div class="col-xl-12">
        <div class="card">
            <div class="card-body">
                <h5 class="fw-semibold">DETAIL </h5>

                <div class="table-responsive">
                    <table class="table">
                        <tbody>
                            <tr>
                                <th scope="col">ID Complet</th>
                                <td scope="col"><?php echo e($log->causer_id); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">ID Utilisateur</th>
                                <td><?php echo e($log->getCauser($log->causer_id)->id); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Email</th>
                                <td><?php echo e($log->getCauser($log->causer_id)->email); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Role du Modificateur</th>
                                <td>
                                    <?php if($log->getCauser($log->causer_id)->role == 'vendor'): ?>
                                    <span class="badge badge-soft-danger">Vendeur</span>
                                    <?php endif; ?>

                                    <?php if($log->getCauser($log->causer_id)->role == 'admin'): ?>
                                    <span class="badge badge-soft-success">Administrateur</span>
                                    <?php endif; ?>

                                    <?php if($log->getCauser($log->causer_id)->role == 'assistant'): ?>
                                    <span class="badge badge-soft-primary">Assistance</span>
                                    <?php endif; ?>

                                    <?php if($log->getCauser($log->causer_id)->role == 'superviseur'): ?>
                                    <span class="badge badge-soft-primary">Superviseur</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Date de creation de L'historique</th>
                                <td><?php echo e($log->created_at); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Date de Modification</th>
                                <td><?php echo e($log->created_at); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Module Modifié</th>
                                <td>
                                    <?php if($log->subject_type == 'App\Models\User'): ?>
                                        Utilisateur
                                    <?php endif; ?>
                                    <?php if($log->subject_type == 'App\Models\Event'): ?>
                                        Calendrier
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Type de Modification</th>
                                <td><?php echo e($log->description); ?></td>
                            </tr>
                            <tr>
                                <?php $myarray = json_decode($log->properties,true); 
                                ?>
                                <th scope="row">Propriétés modifiées (Nouvelle Informations) :</th>
                            </tr>
                            <?php if($log->subject_type == 'App\Models\User'): ?>
                            <tr>
                                <th scope="row">ID</th>
                                <td><?php echo e($myarray['attributes']['id']); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Nom</th>
                                <td><?php echo e($myarray['attributes']['name']); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Email</th>
                                <td><?php echo e($myarray['attributes']['email']); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Mot de Passe</th>
                                <td><?php echo e($myarray['attributes']['password'] == $myarray['old']['password'] ? 'Mot de passe non changé '.$myarray['attributes']['created_at'] 
                                : 'Mot de passe changé le '. date('d-M-Y   h:i:s', strtotime($myarray['attributes']['created_at'])). ' par : '.$log->getCauser($log->causer_id)->name); ?>

                                </td> 
                            </tr>
                            <tr>
                                <th scope="row">Couleur</th>
                                <td><input type="color" name="color" id="color" value="<?php echo e($myarray['attributes']['color']); ?>" disabled></td>
                            </tr>
                            <tr>
                                <th scope="row">Texte Coleur</th>
                                <td><input type="color" name="textColor" id="textColor" value="<?php echo e($myarray['attributes']['textColor']); ?>" disabled></td>
                            </tr>
                            <tr>
                                <th scope="row">Role</th>
                                <td>
                                    <?php if( $myarray['attributes']['role'] == 'vendor'): ?>
                                        Vendeur
                                    <?php endif; ?>
                                    <?php if( $myarray['attributes']['role'] == 'admin'): ?>
                                        Administrateur
                                    <?php endif; ?>
                                    <?php if( $myarray['attributes']['role'] == 'assistant'): ?>
                                        Assistant(e)
                                    <?php endif; ?>
                                    <?php if( $myarray['attributes']['role'] == 'superviseur'): ?>
                                        Superviseur
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endif; ?>
                            <tr>
                                <?php $myarray = json_decode($log->properties,true); 
                                ?>
                                <th scope="row">Propriétés modifiées (Anciennes informations) :</th>
                            </tr>
                            <?php if($log->subject_type == 'App\Models\User'): ?>
                            <tr>
                                <th scope="row">ID</th>
                                <td><?php echo e($myarray['old']['id']); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Nom</th>
                                <td><?php echo e($myarray['old']['name']); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Email</th>
                                <td><?php echo e($myarray['old']['email']); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Mot de Passe</th>
                                <td><?php echo e($myarray['attributes']['password'] == $myarray['old']['password'] ? 'Mot de passe non changé '.date('d-M-Y   h:i:s', strtotime($myarray['old']['created_at'])). ' par : '.$log->getCauser($log->causer_id)->name
                                : 'Mot de passe changé le '. date('d-M-Y   h:i:s', strtotime($myarray['old']['created_at'])). ' par : '.$log->getCauser($log->causer_id)->name); ?>

                                </td> 
                            </tr>
                            <tr>
                                <th scope="row">Couleur</th>
                                <td><input type="color" name="color" id="color" value="<?php echo e($myarray['old']['color']); ?>" disabled></td>
                            </tr>
                            <tr>
                                <th scope="row">Texte Coleur</th>
                                <td><input type="color" name="textColor" id="textColor" value="<?php echo e($myarray['old']['textColor']); ?>" disabled></td>
                            </tr>
                            <tr>
                                <th scope="row">Role</th>
                                <td>
                                    <?php if( $myarray['old']['role'] == 'vendor'): ?>
                                        Vendeur
                                    <?php endif; ?>
                                    <?php if( $myarray['old']['role'] == 'admin'): ?>
                                        Administrateur
                                    <?php endif; ?>
                                    <?php if( $myarray['old']['role'] == 'assistant'): ?>
                                        Assistant(e)
                                    <?php endif; ?>
                                    <?php if( $myarray['old']['role'] == 'superviseur'): ?>
                                        Superviseur
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endif; ?>
                        <?php if($log->subject_type == 'App\Models\Event'): ?>
                           <tr>
                            <?php $myarray = json_decode($log->properties,true); 
                            ?>
                            <th scope="row">Propriétés modifiées (Nouvelle Informations) :</th>
                        </tr>
                        <?php if($log->subject_type == 'App\Models\User'): ?>
                        <tr>
                            <th scope="row">ID</th>
                            <td><?php echo e($myarray['attributes']['id']); ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Nom</th>
                            <td><?php echo e($myarray['attributes']['name']); ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Email</th>
                            <td><?php echo e($myarray['attributes']['email']); ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Mot de Passe</th>
                            <td><?php echo e($myarray['attributes']['password'] == $myarray['old']['password'] ? 'Mot de passe non changé '.$myarray['attributes']['created_at'] 
                            : 'Mot de passe changé le '. date('d-M-Y   h:i:s', strtotime($myarray['attributes']['created_at'])). ' par : '.$log->getCauser($log->causer_id)->name); ?>

                            </td> 
                        </tr>
                        <tr>
                            <th scope="row">Couleur</th>
                            <td><input type="color" name="color" id="color" value="<?php echo e($myarray['attributes']['color']); ?>" disabled></td>
                        </tr>
                        <tr>
                            <th scope="row">Texte Coleur</th>
                            <td><input type="color" name="textColor" id="textColor" value="<?php echo e($myarray['attributes']['textColor']); ?>" disabled></td>
                        </tr>
                        <tr>
                            <th scope="row">Role</th>
                            <td>
                                <?php if( $myarray['attributes']['role'] == 'vendor'): ?>
                                    Vendeur
                                <?php endif; ?>
                                <?php if( $myarray['attributes']['role'] == 'admin'): ?>
                                    Administrateur
                                <?php endif; ?>
                                <?php if( $myarray['attributes']['role'] == 'assistant'): ?>
                                    Assistant(e)
                                <?php endif; ?>
                                <?php if( $myarray['attributes']['role'] == 'superviseur'): ?>
                                    Superviseur
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endif; ?>
                        <tr>
                            <?php $myarray = json_decode($log->properties,true); 
                            ?>
                            <th scope="row">Propriétés modifiées (Anciennes informations) :</th>
                        </tr>
                        <?php if($log->subject_type == 'App\Models\User'): ?>
                        <tr>
                            <th scope="row">ID</th>
                            <td><?php echo e($myarray['old']['id']); ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Nom</th>
                            <td><?php echo e($myarray['old']['name']); ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Email</th>
                            <td><?php echo e($myarray['old']['email']); ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Mot de Passe</th>
                            <td><?php echo e($myarray['attributes']['password'] == $myarray['old']['password'] ? 'Mot de passe non changé '.date('d-M-Y   h:i:s', strtotime($myarray['old']['created_at'])). ' par : '.$log->getCauser($log->causer_id)->name
                            : 'Mot de passe changé le '. date('d-M-Y   h:i:s', strtotime($myarray['old']['created_at'])). ' par : '.$log->getCauser($log->causer_id)->name); ?>

                            </td> 
                        </tr>
                        <tr>
                            <th scope="row">Couleur</th>
                            <td><input type="color" name="color" id="color" value="<?php echo e($myarray['old']['color']); ?>" disabled></td>
                        </tr>
                        <tr>
                            <th scope="row">Texte Coleur</th>
                            <td><input type="color" name="textColor" id="textColor" value="<?php echo e($myarray['old']['textColor']); ?>" disabled></td>
                        </tr>
                        <tr>
                            <th scope="row">Role</th>
                            <td>
                                <?php if( $myarray['old']['role'] == 'vendor'): ?>
                                    Vendeur
                                <?php endif; ?>
                                <?php if( $myarray['old']['role'] == 'admin'): ?>
                                    Administrateur
                                <?php endif; ?>
                                <?php if( $myarray['old']['role'] == 'assistant'): ?>
                                    Assistant(e)
                                <?php endif; ?>
                                <?php if( $myarray['old']['role'] == 'superviseur'): ?>
                                    Superviseur
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endif; ?>
                           <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div><!--end col-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('myjs'); ?>
<script>
    $(document).ready(function(){
        $.ajaxSetup(
            {
                headers:{
                'X-CSRF-TOKEN' : $('meta[name="csrf-token"]').attr('content')
            }
            }
        );
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.masterV2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ovm-calendar\resources\views/logs/detail.blade.php ENDPATH**/ ?>