

<?php $__env->startSection('mycss'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.css" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.24.0/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/locale/fr.js"></script>
<script src="https://npmcdn.com/flatpickr@4.6.13/dist/l10n/fr.js"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
<script src="https://cdn.jsdelivr.net/npm/flatpickr" defer></script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('mytitle'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0 font-size-18">Gestion des Utilisateurs</h4>
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Gestion des Utilisateurs</a></li>
                    <li class="breadcrumb-item active">Acceuil</li>
                </ol>
            </div>
        </div>
    </div>
    <div>
    </div>
</div>
<div class="row">
  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="col-xl-3 col-sm-6">
    <div class="card text-center" >
        <div class="card-body" style="position: relative">
            <div style="position: absolute; right: 20px; top:20px">
                <?php if($user->role != 'admin'): ?>
                <form action="<?php echo e(route('user-delete',['id' => $user->id])); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button class="btn" type="submit"  style="font-size: 30px;"><i class="bx bxs-trash" style="color:rgb(247, 81, 81)"></i></button>
                </form>
                <?php endif; ?>
            </div>
            <div class="mb-4">
                <img class="rounded-circle avatar-sm" src="<?php echo e(URL('storage/'.$user->avatar)); ?>" alt="">
            </div>
            <h5 class="font-size-15 mb-1"><a href="javascript: void(0);" class="text-dark"><?php echo e($user->name); ?></a></h5>
            <p class="text-muted"><?php echo e($user->role); ?></p>
            
        </div>
        <div class="card-footer bg-transparent border-top">
            <div class="contact-links d-flex font-size-20">
                <div class="flex-fill">
                    <a href="javascript: void(0);"><i class="bx bx-message-square-dots"></i></a>
                </div>
                <div class="flex-fill">
                    <a href="javascript: void(0);"><i class="bx bx-pie-chart-alt"></i></a>
                </div>
                <div class="flex-fill">
                    <a href="<?php echo e(route('users-edit',['id' => $user->id])); ?>"><i class="bx bx-user-circle"></i></a>
                </div>
            </div>
        </div>
    </div>
</div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<!-- end row -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('myjs'); ?>
<script src="assets/js/app.js"></script>  

<script>
    $(document).ready(function(){
        $.ajaxSetup(
            {
                headers:{
                'X-CSRF-TOKEN' : $('meta[name="csrf-token"]').attr('content')
            }
            }
        );
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.masterV2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ovm-calendar\resources\views/users/index.blade.php ENDPATH**/ ?>