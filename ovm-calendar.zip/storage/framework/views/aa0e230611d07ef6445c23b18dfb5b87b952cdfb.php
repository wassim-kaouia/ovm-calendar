<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title><?php echo $__env->yieldContent('title'); ?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="Calendar Management Systeme For OVM By Wassim Kaouia" name="description" />
        <meta content="Wassim Kaouia" name="author" />
        <!-- App favicon -->
        
        <!-- Bootstrap Css -->
        <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" id="bootstrap-style" rel="stylesheet" type="text/css" />
        <!-- Icons Css -->
        <link href="<?php echo e(asset('assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
        <!-- App Css-->
        <link href="<?php echo e(asset('assets/css/app.min.css')); ?>" id="app-style" rel="stylesheet" type="text/css" />
        <?php echo $__env->yieldContent('mycss'); ?>
    </head>
    <body data-sidebar="dark" data-layout-mode="light">
        <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- <body data-layout="horizontal" data-topbar="dark"> -->
        <!-- Begin page -->
        <div id="layout-wrapper">
            <header id="page-topbar">
                <div class="navbar-header">
                    <div class="d-flex">
                        <!-- LOGO -->
                        <div class="navbar-brand-box">
                            <a href="" class="logo logo-dark">
                                <span class="logo-sm">
                                    
                                </span>
                                <span class="logo-lg">
                                    
                                </span>
                            </a>
                            <a href="" class="logo logo-light">
                                <span class="logo-sm">
                                    
                                </span>
                                <span class="logo-lg">
                                    <img src="<?php echo e(asset('/assets/images/logo-ovm.png')); ?>" alt="" height="26">
                                </span>
                            </a>
                        </div>
                        <button type="button" class="btn btn-sm px-3 font-size-16 header-item waves-effect" id="vertical-menu-btn">
                            <i class="fa fa-fw fa-bars"></i>
                        </button>
                    </div>
                    <div class="d-flex">
                        <div class="dropdown d-none d-lg-inline-block ms-1">
                            <button type="button" class="btn header-item noti-icon waves-effect" data-bs-toggle="fullscreen">
                                <i class="bx bx-fullscreen"></i>
                            </button>
                        </div>
                        <div class="dropdown d-inline-block">
                            
                        <div class="dropdown d-inline-block">
                            <button type="button" class="btn header-item waves-effect" id="page-header-user-dropdown"
                            data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <img class="rounded-circle header-profile-user" src="<?php echo e(Auth::user()->avatar == 'avatar/default/avatar.png' ? asset(Auth::user()->avatar) : URL('storage/'.Auth::user()->avatar)); ?>"
                                    alt="Header Avatar">
                                <span class="d-none d-xl-inline-block ms-1" key="t-henry"><?php echo e(Auth::user()->name); ?></span>
                                <i class="mdi mdi-chevron-down d-none d-xl-inline-block"></i>
                            </button>
                            <div class="dropdown-menu dropdown-menu-end">
                                <!-- item-->
                                <a class="dropdown-item" href="<?php echo e(route('get-profile',['id' => Auth::user()->id])); ?>"><i class="bx bx-user font-size-16 align-middle me-1"></i> <span key="t-profile">Profile</span></a>
                                <a class="dropdown-item d-block" href="#"> <i class="bx bx-wrench font-size-16 align-middle me-1"></i> <span key="t-settings">Settings</span></a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item text-danger" href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault();
                                              document.getElementById('logout-form').submit();">
                                <i class="bx bx-power-off font-size-16 align-middle me-1 text-danger"></i> <?php echo e(__('Logout')); ?></a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <!-- ========== Left Sidebar Start ========== -->
            <div class="vertical-menu">
                <div data-simplebar class="h-100">
                    <!--- Sidemenu -->
                    <div id="sidebar-menu">
                        <!-- Left Menu Start -->
                        <ul class="metismenu list-unstyled" id="side-menu">
                            <li class="menu-title" key="t-menu">Menu</li>
                            
                            <li class="mm-active">
                                <a href="<?php echo e(route('users-list')); ?>" class="waves-effect active">
                                    <i class="bx bx-user-circle"></i>
                                    <span key="t-starter-page">Gestion des Utilisateurs</span>
                                </a>
                            </li>
                            <li class="mm-active">
                                <a href="<?php echo e(route('get-add-page')); ?>" class="waves-effect active">
                                    <i class="bx bx-user-circle"></i>
                                    <span key="t-starter-page">Ajouter un Utilisateur</span>
                                </a>
                            </li>
                            <li class="mm-active">
                                <a href="<?php echo e(route('calendrier-index')); ?>" class="waves-effect active">
                                    <i class="bx bx-home-circle"></i>
                                    <span key="t-starter-page">Calendrier</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <!-- Sidebar -->
                </div>
            </div>
            <!-- Left Sidebar End -->
            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">
                <div class="page-content">
                    <div class="container-fluid">
                        <!-- start page title -->
                        <?php echo $__env->yieldContent('content'); ?>
                        <!-- end page title -->
                    </div> <!-- container-fluid -->
                </div>
            <!-- End Page-content -->
                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-sm-6">
                                <script>document.write(new Date().getFullYear())</script> © WassCalendario.
                            </div>
                            <div class="col-sm-6">
                                <div class="text-sm-end d-none d-sm-block">
                                   Developed By Wassim Kaouia - for OVM aka Memory Rituals LTD, Portugal
                                </div>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
            <!-- end main content-->
        </div>
        <!-- END layout-wrapper -->
        

        <!-- Right bar overlay-->
        <div class="rightbar-overlay"></div>

       
         <!-- JAVASCRIPT -->
 <script src="<?php echo e(asset('assets/libs/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
 <script src="<?php echo e(asset('assets/libs/simplebar/simplebar.min.js')); ?>"></script>
 <script src="<?php echo e(asset('assets/libs/metismenu/metisMenu.min.js')); ?>"></script>
 <script src="<?php echo e(asset('assets/libs/node-waves/waves.min.js')); ?>"></script>
 <script src="./assets/js/app.js"></script>    
<?php echo $__env->yieldContent('myjs'); ?>  
<!-- plugin js -->

    </body>
</html>
<?php /**PATH C:\xampp\htdocs\ovm-calendar\resources\views/layout/masterV2.blade.php ENDPATH**/ ?>