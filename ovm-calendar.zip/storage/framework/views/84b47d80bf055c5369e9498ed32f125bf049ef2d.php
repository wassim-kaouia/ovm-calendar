<!DOCTYPE html>
<html>
<head>
    <title><?php echo $__env->yieldContent('title'); ?></title>
    
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    
    <?php echo $__env->yieldContent('jscss-urls'); ?>
</head>
<body>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('content'); ?>  
   
<?php echo $__env->yieldContent('js'); ?>
  
</body>
</html>
<?php /**PATH C:\xampp\htdocs\ovm-calendar\resources\views/layout/master.blade.php ENDPATH**/ ?>